package com.example.ayurchain;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class CollectorHomeActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;

    private EditText etTotalQuantity, etStorageConditions, etGpsCoordinates, etTransportPlan;
    private Button btnGetCoordinates, btnSubmit, btnUploadPhotos;

    private String photosHash = ""; // Stores uploaded photos hash

    private FusedLocationProviderClient fusedLocationClient;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.collectorhome);

        // Initialize views
        etTotalQuantity = findViewById(R.id.input_total_quantity);
        etStorageConditions = findViewById(R.id.input_storage_conditions);
        etGpsCoordinates = findViewById(R.id.input_gps_coordinates);
        etTransportPlan = findViewById(R.id.input_transport_plan);

        btnGetCoordinates = findViewById(R.id.btn1);
        btnSubmit = findViewById(R.id.btn_submit_packaging);
        btnUploadPhotos = findViewById(R.id.btn_upload_aggregated_photos);

        databaseHelper = new DatabaseHelper(this);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Fetch GPS coordinates
        btnGetCoordinates.setOnClickListener(v -> fetchCurrentCoordinates());

        // Handle photo upload
        btnUploadPhotos.setOnClickListener(v -> {
            // TODO: Implement actual file upload logic
            // For now, we assign a sample hash
            photosHash = "sample_uploaded_file_hash";
            Toast.makeText(this, "Photos uploaded successfully!", Toast.LENGTH_SHORT).show();
        });

        // Save collector data and open QR page
        btnSubmit.setOnClickListener(v -> saveCollectorData());
    }

    private void fetchCurrentCoordinates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                etGpsCoordinates.setText(location.getLatitude() + ", " + location.getLongitude());
            } else {
                Toast.makeText(this, "Unable to fetch location. Try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveCollectorData() {
        String totalQty = etTotalQuantity.getText().toString().trim();
        String storage = etStorageConditions.getText().toString().trim();
        String gps = etGpsCoordinates.getText().toString().trim();
        String transportPlan = etTransportPlan.getText().toString().trim();

        if (totalQty.isEmpty()) {
            etTotalQuantity.setError("Enter total quantity");
            etTotalQuantity.requestFocus();
            return;
        }
        if (storage.isEmpty()) {
            etStorageConditions.setError("Enter storage conditions");
            etStorageConditions.requestFocus();
            return;
        }
        if (gps.isEmpty()) {
            etGpsCoordinates.setError("GPS coordinates required");
            etGpsCoordinates.requestFocus();
            return;
        }

        // Insert collector data into DB
        boolean inserted = databaseHelper.insertCollectorData(
                "aggregator_001", // Replace with actual aggregator/user ID
                "batch_001",      // Replace with aggregated batch IDs
                totalQty,
                storage,
                gps,
                transportPlan,
                photosHash // Use string variable
        );

        if (inserted) {
            Toast.makeText(this, "Data saved successfully!", Toast.LENGTH_SHORT).show();

            // Launch qr2.java (Retailer QR) dynamically
            Intent intent = new Intent(CollectorHomeActivity.this, qr2.class);
            intent.putExtra("RETAILER_ID", "retailer_001");
            intent.putExtra("RETAILER_NAME", "John's Herbal Store");
            intent.putExtra("STORE_LOCATION", gps); // Use GPS dynamically
            intent.putExtra("RECEIVED_BATCH_IDS", "batch_001");
            intent.putExtra("CONTACT", "9876543210");
            intent.putExtra("EMAIL", "retailer@example.com");
            startActivity(intent);

            // Clear fields
            etTotalQuantity.setText("");
            etStorageConditions.setText("");
            etGpsCoordinates.setText("");
            etTransportPlan.setText("");
            photosHash = "";
        } else {
            Toast.makeText(this, "Failed to save data.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchCurrentCoordinates();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
