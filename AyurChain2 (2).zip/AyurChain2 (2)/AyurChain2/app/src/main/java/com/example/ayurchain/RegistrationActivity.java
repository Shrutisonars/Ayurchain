package com.example.ayurchain;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RegistrationActivity extends AppCompatActivity {

    private EditText etUserId, etName, etContact, etEmail, etWallet, etLegalId, etAddress, etPassword;
    private TextView tvDate;
    private Spinner roleSpinner;
    private ImageButton btnRegister;

    private String selectedRole = "";
    private DatabaseHelper databaseHelper;

    // Mapping of spinner positions to activity classes
    private final Class<?>[] roleActivities = new Class<?>[]{
            FarmerHomeActivity.class,        // Farmer
            CollectorHomeActivity.class,     // Local Collector
            PackagingUnitHomeActivity.class,     // Packaging Unit
            WholesellerHomeActivity.class,    // Wholeseller
            RetailerHomeActivity.class       // Retailer
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration); // your layout

        // Initialize DB helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        etUserId = findViewById(R.id.et_userid);
        etName = findViewById(R.id.et_name);
        etContact = findViewById(R.id.et_contact);
        etEmail = findViewById(R.id.et_email);
        etWallet = findViewById(R.id.et_wallet);
        etLegalId = findViewById(R.id.et_legalid);
        etAddress = findViewById(R.id.et_address);
        etPassword = findViewById(R.id.et_password);
        tvDate = findViewById(R.id.tv_date);
        roleSpinner = findViewById(R.id.role_spinner);
        btnRegister = findViewById(R.id.btn_register);

        // Generate current date
        String currentDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        tvDate.setText(currentDate);

        // Spinner listener
        roleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                Object item = parent.getItemAtPosition(position);
                selectedRole = item != null ? item.toString().trim() : "";
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedRole = "";
            }
        });

        // Register button click
        btnRegister.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {
        String userId = etUserId.getText() != null ? etUserId.getText().toString().trim() : "";
        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String contact = etContact.getText() != null ? etContact.getText().toString().trim() : "";
        String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
        String wallet = etWallet.getText() != null ? etWallet.getText().toString().trim() : "";
        String legalId = etLegalId.getText() != null ? etLegalId.getText().toString().trim() : "";
        String address = etAddress.getText() != null ? etAddress.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        // fallback if spinner listener hasn't fired
        String role = (selectedRole == null || selectedRole.isEmpty()) && roleSpinner.getSelectedItem() != null
                ? roleSpinner.getSelectedItem().toString().trim()
                : selectedRole;

        // Simple validation
        if (userId.isEmpty()) {
            etUserId.setError("User ID required");
            etUserId.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            etPassword.setError("Password required");
            etPassword.requestFocus();
            return;
        }
        if (role == null || role.isEmpty()) {
            Toast.makeText(this, "Please select a role", Toast.LENGTH_SHORT).show();
            return;
        }

        // registration datetime in DB-friendly format
        String regDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        // Insert into SQLite via DatabaseHelper
        boolean inserted = databaseHelper.insertUser(
                userId, name, contact, email, wallet, legalId, address, password, role, regDate
        );

        if (inserted) {
            Toast.makeText(this, "Registration successful as " + role, Toast.LENGTH_LONG).show();

            int position = roleSpinner.getSelectedItemPosition();
            Class<?> targetActivity = (position >= 0 && position < roleActivities.length)
                    ? roleActivities[position]
                    : MainActivity.class; // fallback

            Intent intent = new Intent(this, targetActivity);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Registration failed (user ID may already exist)", Toast.LENGTH_LONG).show();
        }
    }
}
