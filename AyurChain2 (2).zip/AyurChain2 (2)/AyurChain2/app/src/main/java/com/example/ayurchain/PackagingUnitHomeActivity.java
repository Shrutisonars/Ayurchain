package com.example.ayurchain;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class PackagingUnitHomeActivity extends AppCompatActivity {

    private static final int REQUEST_LOCATION = 100;
    private static final int REQUEST_PHOTOS = 101;

    private EditText inputTotalQuantity, inputStorageConditions, inputTransportPlan;
    private TextView textAggregationGPS;
    private Button btnFetchLocation, btnUploadPhotos, btnSubmit, btnScanQR;

    private FusedLocationProviderClient fusedLocationClient;

    // QR Scanner launcher
    private ActivityResultLauncher<ScanOptions> qrScannerLauncher;

    // DB helper
    private DatabaseHelper databaseHelper;

    // store selected photo URI as string (used as photosHash placeholder)
    private String selectedPhotoUriString = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.packagingunithome); // your XML file name

        // Initialize DB helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        inputTotalQuantity = findViewById(R.id.input_total_quantity);
        inputStorageConditions = findViewById(R.id.input_storage_conditions);
        inputTransportPlan = findViewById(R.id.input_transport_plan);

        textAggregationGPS = findViewById(R.id.text_aggregation_gps);
        btnFetchLocation = findViewById(R.id.btn_fetch_aggregation_location);
        btnUploadPhotos = findViewById(R.id.btn_upload_aggregated_photos);
        btnSubmit = findViewById(R.id.btn_submit_packaging);
        btnScanQR = findViewById(R.id.btn_scan_qr);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Initialize QR scanner launcher
        qrScannerLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (result != null && result.getContents() != null) {
                Toast.makeText(this, "QR Code: " + result.getContents(), Toast.LENGTH_LONG).show();
                // Optional: populate a field with scanned info
                inputTransportPlan.setText(result.getContents());
            }
        });

        // Button listeners
        if (btnFetchLocation != null) btnFetchLocation.setOnClickListener(v -> fetchCurrentLocation());
        if (btnUploadPhotos != null) btnUploadPhotos.setOnClickListener(v -> uploadPhotos());
        if (btnSubmit != null) btnSubmit.setOnClickListener(v -> submitPackagingInfo());
        if (btnScanQR != null) btnScanQR.setOnClickListener(v -> scanQRCode());
    }

    // Fetch GPS location
    private void fetchCurrentLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                if (location != null) {
                    String gpsText = "Lat: " + location.getLatitude() +
                            ", Lon: " + location.getLongitude();
                    textAggregationGPS.setText(gpsText);
                    Toast.makeText(this, "Location fetched", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Unable to fetch location", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(e -> {
                Toast.makeText(this, "Location fetch failed", Toast.LENGTH_SHORT).show();
                Log.e("PACKAGING_LOC", "error fetching location", e);
            });
        }
    }

    // Upload photos from gallery (single image)
    private void uploadPhotos() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_PHOTOS);
    }

    // Launch QR scanner
    private void scanQRCode() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("Scan a QR code");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        qrScannerLauncher.launch(options);
    }

    // Submit the packaging form and save to SQLite
    private void submitPackagingInfo() {
        String totalQty = getTextSafe(inputTotalQuantity);
        String storage = getTextSafe(inputStorageConditions);
        String gps = getTextSafe(textAggregationGPS);
        String transportPlan = getTextSafe(inputTransportPlan);

        // basic validation
        if (totalQty.isEmpty()) {
            Toast.makeText(this, "Please enter total quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        // photosHash: currently storing selected photo URI string as placeholder
        String photosHash = selectedPhotoUriString == null ? "" : selectedPhotoUriString;

        boolean saved = false;
        try {
            saved = databaseHelper.insertPackagingData(totalQty, storage, gps, transportPlan, photosHash);
        } catch (Exception e) {
            Log.e("DB_ERROR", "Error inserting packaging data", e);
            saved = false;
        }

        if (saved) {
            Toast.makeText(this, "Packaging info saved successfully", Toast.LENGTH_LONG).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to save packaging info", Toast.LENGTH_LONG).show();
        }
    }

    // Helpers to safely get text from views
    private String getTextSafe(EditText et) {
        return (et == null || et.getText() == null) ? "" : et.getText().toString().trim();
    }

    private String getTextSafe(TextView tv) {
        return (tv == null || tv.getText() == null) ? "" : tv.getText().toString().trim();
    }

    private void clearFields() {
        if (inputTotalQuantity != null) inputTotalQuantity.setText("");
        if (inputStorageConditions != null) inputStorageConditions.setText("");
        if (inputTransportPlan != null) inputTransportPlan.setText("");
        if (textAggregationGPS != null) textAggregationGPS.setText("");
        selectedPhotoUriString = "";
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (resultCode == RESULT_OK && data != null) {
                Uri selectedFile = data.getData();
                if (requestCode == REQUEST_PHOTOS && selectedFile != null) {
                    // Use the selected image URI as a placeholder for photosHash
                    selectedPhotoUriString = selectedFile.toString();
                    Toast.makeText(this, "Photo selected: " + selectedPhotoUriString, Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            Log.e("PACKAGING_PHOTO", "photo selection error", e);
            Toast.makeText(this, "Error selecting photo", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (requestCode == REQUEST_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchCurrentLocation();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
