package com.example.ayurchain;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Info
    private static final String DATABASE_NAME = "AyurChain.db";
    private static final int DATABASE_VERSION = 6; // Incremented for QR table

    // Table Names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_FARMER_DATA = "farmer_data";
    private static final String TABLE_COLLECTOR_DATA = "collector_data";
    private static final String TABLE_PACKAGING_DATA = "packaging_data";
    private static final String TABLE_WHOLESALER_DATA = "wholesaler_data";
    private static final String TABLE_RETAILER_DATA = "retailer_data";
    private static final String TABLE_QR_CODE_DATA = "qr_code_data"; // New table

    // Common Column
    private static final String COL_ID = "id";

    // User Columns
    private static final String COL_USER_ID = "user_id";
    private static final String COL_USER_NAME = "name";
    private static final String COL_USER_CONTACT = "contact";
    private static final String COL_USER_EMAIL = "email";
    private static final String COL_USER_WALLET = "wallet";
    private static final String COL_USER_LEGAL_ID = "legal_id";
    private static final String COL_USER_ADDRESS = "address";
    private static final String COL_USER_PASSWORD = "password";
    private static final String COL_USER_ROLE = "role";
    private static final String COL_USER_REG_DATE = "reg_date";

    // Farmer Data Columns
    private static final String COL_FARMER_USER_ID = "user_id";
    private static final String COL_BATCH_ID = "batch_id";
    private static final String COL_COLLECTION_DATETIME = "collection_datetime";
    private static final String COL_HERB_SPECIES = "herb_species";
    private static final String COL_VARIETY = "variety";
    private static final String COL_QUANTITY = "quantity";
    private static final String COL_MOISTURE = "moisture";
    private static final String COL_SOIL_ID = "soil_id";
    private static final String COL_QUALITY_NOTES = "quality_notes";
    private static final String COL_GEO_COORDINATES = "geo_coordinates";
    private static final String COL_HARVEST_METHOD = "harvest_method";
    private static final String COL_FARMER_PHOTOS_HASH = "photos_hash";
    private static final String COL_CERTIFICATES_HASH = "certificates_hash";

    // Collector Data Columns
    private static final String COL_AGGREGATOR_ID = "aggregator_id";
    private static final String COL_AGGREGATED_BATCH_IDS = "aggregated_batch_ids";
    private static final String COL_TOTAL_QUANTITY = "total_quantity";
    private static final String COL_STORAGE_CONDITIONS = "storage_conditions";
    private static final String COL_GPS_COORDINATES = "gps_coordinates";
    private static final String COL_TRANSPORT_PLAN_ID = "transport_plan_id";
    private static final String COL_COLLECTOR_PHOTOS_HASH = "photos_hash";

    // Packaging Data Columns
    private static final String COL_PACKAGING_TOTAL_QUANTITY = "total_quantity";
    private static final String COL_PACKAGING_STORAGE_CONDITIONS = "storage_conditions";
    private static final String COL_PACKAGING_GPS_COORDINATES = "gps_coordinates";
    private static final String COL_PACKAGING_TRANSPORT_PLAN_ID = "transport_plan_id";
    private static final String COL_PACKAGING_PHOTOS_HASH = "photos_hash";

    // Wholesaler Data Columns
    private static final String COL_WAREHOUSE_LOCATION = "warehouse_location";
    private static final String COL_RECEIVING_DATETIME = "receiving_datetime";
    private static final String COL_WHOLESALER_BATCH_IDS = "batch_ids";
    private static final String COL_QUANTITY_RECEIVED = "quantity_received";
    private static final String COL_DISPATCH_DATETIME = "dispatch_datetime";
    private static final String COL_TRANSPORT_MODE = "transport_mode";
    private static final String COL_INVOICE_NUMBER = "invoice_number";
    private static final String COL_DOCUMENTS_HASH = "documents_hash";
    private static final String COL_WHOLESALER_STORAGE_CONDITIONS = "storage_conditions";

    // Retailer Data Columns
    private static final String COL_RETAILER_RECEIPT_DATETIME = "receipt_datetime";
    private static final String COL_RETAILER_BATCH_IDS = "batch_ids";
    private static final String COL_RETAILER_QUANTITY_RECEIVED = "quantity_received";
    private static final String COL_RETAILER_STORAGE_CONDITIONS = "storage_conditions";

    // QR Code Columns
    private static final String COL_QR_CONTENT = "qr_content";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // USERS Table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_USER_ID + " TEXT,"
                + COL_USER_NAME + " TEXT,"
                + COL_USER_CONTACT + " TEXT,"
                + COL_USER_EMAIL + " TEXT,"
                + COL_USER_WALLET + " TEXT,"
                + COL_USER_LEGAL_ID + " TEXT,"
                + COL_USER_ADDRESS + " TEXT,"
                + COL_USER_PASSWORD + " TEXT,"
                + COL_USER_ROLE + " TEXT,"
                + COL_USER_REG_DATE + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        // FARMER_DATA Table
        String CREATE_FARMER_DATA_TABLE = "CREATE TABLE " + TABLE_FARMER_DATA + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_FARMER_USER_ID + " TEXT,"
                + COL_BATCH_ID + " TEXT,"
                + COL_COLLECTION_DATETIME + " TEXT,"
                + COL_HERB_SPECIES + " TEXT,"
                + COL_VARIETY + " TEXT,"
                + COL_QUANTITY + " TEXT,"
                + COL_MOISTURE + " TEXT,"
                + COL_SOIL_ID + " TEXT,"
                + COL_QUALITY_NOTES + " TEXT,"
                + COL_GEO_COORDINATES + " TEXT,"
                + COL_HARVEST_METHOD + " TEXT,"
                + COL_FARMER_PHOTOS_HASH + " TEXT,"
                + COL_CERTIFICATES_HASH + " TEXT" + ")";
        db.execSQL(CREATE_FARMER_DATA_TABLE);

        // COLLECTOR_DATA Table
        String CREATE_COLLECTOR_DATA_TABLE = "CREATE TABLE " + TABLE_COLLECTOR_DATA + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_AGGREGATOR_ID + " TEXT,"
                + COL_AGGREGATED_BATCH_IDS + " TEXT,"
                + COL_TOTAL_QUANTITY + " TEXT,"
                + COL_STORAGE_CONDITIONS + " TEXT,"
                + COL_GPS_COORDINATES + " TEXT,"
                + COL_TRANSPORT_PLAN_ID + " TEXT,"
                + COL_COLLECTOR_PHOTOS_HASH + " TEXT" + ")";
        db.execSQL(CREATE_COLLECTOR_DATA_TABLE);

        // PACKAGING_DATA Table
        String CREATE_PACKAGING_DATA_TABLE = "CREATE TABLE " + TABLE_PACKAGING_DATA + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_PACKAGING_TOTAL_QUANTITY + " TEXT,"
                + COL_PACKAGING_STORAGE_CONDITIONS + " TEXT,"
                + COL_PACKAGING_GPS_COORDINATES + " TEXT,"
                + COL_PACKAGING_TRANSPORT_PLAN_ID + " TEXT,"
                + COL_PACKAGING_PHOTOS_HASH + " TEXT" + ")";
        db.execSQL(CREATE_PACKAGING_DATA_TABLE);

        // WHOLESALER_DATA Table
        String CREATE_WHOLESALER_DATA_TABLE = "CREATE TABLE " + TABLE_WHOLESALER_DATA + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_WAREHOUSE_LOCATION + " TEXT,"
                + COL_RECEIVING_DATETIME + " TEXT,"
                + COL_WHOLESALER_BATCH_IDS + " TEXT,"
                + COL_QUANTITY_RECEIVED + " TEXT,"
                + COL_WHOLESALER_STORAGE_CONDITIONS + " TEXT,"
                + COL_DISPATCH_DATETIME + " TEXT,"
                + COL_TRANSPORT_MODE + " TEXT,"
                + COL_INVOICE_NUMBER + " TEXT,"
                + COL_DOCUMENTS_HASH + " TEXT" + ")";
        db.execSQL(CREATE_WHOLESALER_DATA_TABLE);

        // RETAILER_DATA Table
        String CREATE_RETAILER_DATA_TABLE = "CREATE TABLE " + TABLE_RETAILER_DATA + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_RETAILER_RECEIPT_DATETIME + " TEXT,"
                + COL_RETAILER_BATCH_IDS + " TEXT,"
                + COL_RETAILER_QUANTITY_RECEIVED + " TEXT,"
                + COL_RETAILER_STORAGE_CONDITIONS + " TEXT" + ")";
        db.execSQL(CREATE_RETAILER_DATA_TABLE);

        // QR_CODE_DATA Table
        String CREATE_QR_CODE_DATA_TABLE = "CREATE TABLE " + TABLE_QR_CODE_DATA + "("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_QR_CONTENT + " TEXT" + ")";
        db.execSQL(CREATE_QR_CODE_DATA_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FARMER_DATA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COLLECTOR_DATA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PACKAGING_DATA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WHOLESALER_DATA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RETAILER_DATA);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QR_CODE_DATA);
        onCreate(db);
    }

    // ================= Insert Methods ================= //

    // Users
    public boolean insertUser(String userId, String name, String contact, String email,
                              String wallet, String legalId, String address, String password,
                              String role, String regDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USER_ID, userId);
        values.put(COL_USER_NAME, name);
        values.put(COL_USER_CONTACT, contact);
        values.put(COL_USER_EMAIL, email);
        values.put(COL_USER_WALLET, wallet);
        values.put(COL_USER_LEGAL_ID, legalId);
        values.put(COL_USER_ADDRESS, address);
        values.put(COL_USER_PASSWORD, password);
        values.put(COL_USER_ROLE, role);
        values.put(COL_USER_REG_DATE, regDate);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Farmer
    public boolean insertFarmerData(String userId, String batchId, String collectionDatetime,
                                    String herbSpecies, String variety, String quantity,
                                    String moisture, String soilId, String qualityNotes,
                                    String geoCoordinates, String harvestMethod,
                                    String photosHash, String certificatesHash) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_FARMER_USER_ID, userId);
        values.put(COL_BATCH_ID, batchId);
        values.put(COL_COLLECTION_DATETIME, collectionDatetime);
        values.put(COL_HERB_SPECIES, herbSpecies);
        values.put(COL_VARIETY, variety);
        values.put(COL_QUANTITY, quantity);
        values.put(COL_MOISTURE, moisture);
        values.put(COL_SOIL_ID, soilId);
        values.put(COL_QUALITY_NOTES, qualityNotes);
        values.put(COL_GEO_COORDINATES, geoCoordinates);
        values.put(COL_HARVEST_METHOD, harvestMethod);
        values.put(COL_FARMER_PHOTOS_HASH, photosHash);
        values.put(COL_CERTIFICATES_HASH, certificatesHash);
        long result = db.insert(TABLE_FARMER_DATA, null, values);
        return result != -1;
    }

    // Collector
    public boolean insertCollectorData(String aggregatorId, String aggregatedBatchIds, String totalQuantity,
                                       String storageConditions, String gpsCoordinates, String transportPlanId,
                                       String photosHash) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_AGGREGATOR_ID, aggregatorId);
        values.put(COL_AGGREGATED_BATCH_IDS, aggregatedBatchIds);
        values.put(COL_TOTAL_QUANTITY, totalQuantity);
        values.put(COL_STORAGE_CONDITIONS, storageConditions);
        values.put(COL_GPS_COORDINATES, gpsCoordinates);
        values.put(COL_TRANSPORT_PLAN_ID, transportPlanId);
        values.put(COL_COLLECTOR_PHOTOS_HASH, photosHash);
        long result = db.insert(TABLE_COLLECTOR_DATA, null, values);
        return result != -1;
    }

    // Packaging
    public boolean insertPackagingData(String totalQuantity, String storageConditions,
                                       String gpsCoordinates, String transportPlanId, String photosHash) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_PACKAGING_TOTAL_QUANTITY, totalQuantity);
        values.put(COL_PACKAGING_STORAGE_CONDITIONS, storageConditions);
        values.put(COL_PACKAGING_GPS_COORDINATES, gpsCoordinates);
        values.put(COL_PACKAGING_TRANSPORT_PLAN_ID, transportPlanId);
        values.put(COL_PACKAGING_PHOTOS_HASH, photosHash);
        long result = db.insert(TABLE_PACKAGING_DATA, null, values);
        return result != -1;
    }

    // Wholesaler
    public boolean insertWholesalerData(String warehouseLocation, String receivingDatetime, String batchIds,
                                        String quantityReceived, String storageConditions, String dispatchDatetime,
                                        String transportMode, String invoiceNumber, String documentsHash) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_WAREHOUSE_LOCATION, warehouseLocation);
        values.put(COL_RECEIVING_DATETIME, receivingDatetime);
        values.put(COL_WHOLESALER_BATCH_IDS, batchIds);
        values.put(COL_QUANTITY_RECEIVED, quantityReceived);
        values.put(COL_WHOLESALER_STORAGE_CONDITIONS, storageConditions);
        values.put(COL_DISPATCH_DATETIME, dispatchDatetime);
        values.put(COL_TRANSPORT_MODE, transportMode);
        values.put(COL_INVOICE_NUMBER, invoiceNumber);
        values.put(COL_DOCUMENTS_HASH, documentsHash);
        long result = db.insert(TABLE_WHOLESALER_DATA, null, values);
        return result != -1;
    }

    // Retailer
    public boolean insertRetailerData(String receiptDatetime, String batchIds,
                                      String quantityReceived, String storageConditions) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_RETAILER_RECEIPT_DATETIME, receiptDatetime);
        values.put(COL_RETAILER_BATCH_IDS, batchIds);
        values.put(COL_RETAILER_QUANTITY_RECEIVED, quantityReceived);
        values.put(COL_RETAILER_STORAGE_CONDITIONS, storageConditions);
        long result = db.insert(TABLE_RETAILER_DATA, null, values);
        return result != -1;
    }

    // QR Code
    public boolean insertQRCodeData(String qrContent) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_QR_CONTENT, qrContent);
        long result = db.insert(TABLE_QR_CODE_DATA, null, values);
        return result != -1;
    }

    // ================= Get Methods ================= //

    public Cursor getAllQRCodes() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_QR_CODE_DATA, null, null, null, null, null, COL_ID + " DESC");
    }

    // Generic get method for any table
    public Cursor getData(String tableName, String[] columns, String selection, String[] selectionArgs) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(tableName, columns, selection, selectionArgs, null, null, null);
    }
}
