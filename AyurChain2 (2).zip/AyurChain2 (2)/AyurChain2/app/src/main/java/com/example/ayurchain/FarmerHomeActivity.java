package com.example.ayurchain;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class FarmerHomeActivity extends AppCompatActivity {

    private static final int REQUEST_LOCATION = 100;
    private static final int REQUEST_PHOTO = 101;
    private static final int REQUEST_CERTIFICATE = 102;

    private EditText inputCollectionDatetime, inputHerbSpecies, inputVariety,
            inputBatchId, inputQuantity, inputMoisture, inputSoilId, inputQualityNotes;
    private TextView textGeoCoordinates;
    private Button btnFetchLocation, btnUploadCertificates, btnSubmit;
    private ImageButton btnUploadPhotos;
    private Spinner spinnerHarvestMethod;

    private FusedLocationProviderClient fusedLocationClient;
    private DatabaseHelper databaseHelper;

    private String selectedPhotoUriString = "";
    private String selectedCertificateUriString = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.farmerhome);

        // Initialize DB
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        inputCollectionDatetime = findViewById(R.id.input_collection_datetime);
        inputHerbSpecies = findViewById(R.id.input_herb_species);
        inputVariety = findViewById(R.id.input_variety);
        inputBatchId = findViewById(R.id.input_batch_id);
        inputQuantity = findViewById(R.id.input_quantity);
        inputMoisture = findViewById(R.id.input_moisture);
        inputSoilId = findViewById(R.id.input_soil_id);
        inputQualityNotes = findViewById(R.id.input_quality_notes);

        textGeoCoordinates = findViewById(R.id.text_geo_coordinates);
        btnFetchLocation = findViewById(R.id.btn_fetch_location);
        btnUploadPhotos = findViewById(R.id.btn_upload_photos);
        btnUploadCertificates = findViewById(R.id.btn_upload_certificates);
        btnSubmit = findViewById(R.id.btn_submit);
        spinnerHarvestMethod = findViewById(R.id.spinner_harvest_method);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Click listeners
        btnFetchLocation.setOnClickListener(v -> fetchCurrentLocation());
        btnUploadPhotos.setOnClickListener(v -> uploadPhotos());
        btnUploadCertificates.setOnClickListener(v -> uploadCertificates());
        btnSubmit.setOnClickListener(v -> submitCollection());
    }

    private void fetchCurrentLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                if (location != null) {
                    String gpsText = location.getLatitude() + "," + location.getLongitude();
                    textGeoCoordinates.setText(gpsText);
                    Toast.makeText(this, "Location fetched", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Unable to fetch location", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(e -> {
                Log.e("FARMER_LOC", "Location fetch failed", e);
                Toast.makeText(this, "Unable to fetch location", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void uploadPhotos() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_PHOTO);
    }

    private void uploadCertificates() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_CERTIFICATE);
    }

    private void submitCollection() {
        try {
            String userId = getIntent().getStringExtra("USER_ID");
            if (userId == null || userId.isEmpty()) {
                userId = getSharedPreferences("AyurChainPrefs", MODE_PRIVATE)
                        .getString("USER_ID", "UNKNOWN");
            }

            String collectionDateTime = getTextSafe(inputCollectionDatetime);
            String geoCoordinates = getTextSafe(textGeoCoordinates);
            String harvestMethod = spinnerHarvestMethod != null && spinnerHarvestMethod.getSelectedItem() != null
                    ? spinnerHarvestMethod.getSelectedItem().toString().trim()
                    : "";
            String herbSpecies = getTextSafe(inputHerbSpecies);
            String variety = getTextSafe(inputVariety);
            String batchId = getTextSafe(inputBatchId);
            String quantity = getTextSafe(inputQuantity);
            String moisture = getTextSafe(inputMoisture);
            String soilId = getTextSafe(inputSoilId);
            String qualityNotes = getTextSafe(inputQualityNotes);

            if (batchId.isEmpty() || herbSpecies.isEmpty() || quantity.isEmpty()) {
                Toast.makeText(this, "Please fill Batch ID, Herb Species, and Quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            String photosHash = selectedPhotoUriString != null ? selectedPhotoUriString : "";
            String certificatesHash = selectedCertificateUriString != null ? selectedCertificateUriString : "";

            boolean saved = databaseHelper.insertFarmerData(
                    userId, batchId, collectionDateTime, herbSpecies, variety,
                    quantity, moisture, soilId, qualityNotes, geoCoordinates,
                    harvestMethod, photosHash, certificatesHash
            );

            if (saved) {
                Toast.makeText(this, "Collection saved successfully", Toast.LENGTH_LONG).show();

                // Prepare QR content
                String qrContent = "Collection Date: " + collectionDateTime + "\n" +
                        "Geo-coordinates: " + geoCoordinates + "\n" +
                        "Harvest Method: " + harvestMethod + "\n" +
                        "Herb Species: " + herbSpecies + "\n" +
                        "Variety: " + variety + "\n" +
                        "Batch ID: " + batchId + "\n" +
                        "Quantity: " + quantity + "\n" +
                        "Moisture: " + moisture + "\n" +
                        "Soil ID: " + soilId + "\n" +
                        "Quality Notes: " + qualityNotes + "\n" +
                        "Photos Hash: " + photosHash + "\n" +
                        "Certificates Hash: " + certificatesHash;

                // Save QR to DB
                databaseHelper.insertQRCodeData(qrContent);

                // Launch QRCodeActivity
                Intent qrIntent = new Intent(FarmerHomeActivity.this, QRCodeActivity.class);
                qrIntent.putExtra("COLLECTION_DATETIME", collectionDateTime);
                qrIntent.putExtra("GEO_COORDINATES", geoCoordinates);
                qrIntent.putExtra("HARVEST_METHOD", harvestMethod);
                qrIntent.putExtra("HERB_SPECIES", herbSpecies);
                qrIntent.putExtra("VARIETY", variety);
                qrIntent.putExtra("BATCH_ID", batchId);
                qrIntent.putExtra("QUANTITY", quantity);
                qrIntent.putExtra("MOISTURE", moisture);
                qrIntent.putExtra("SOIL_ID", soilId);
                qrIntent.putExtra("QUALITY_NOTES", qualityNotes);
                qrIntent.putExtra("PHOTOS_HASH", photosHash);
                qrIntent.putExtra("CERTIFICATES_HASH", certificatesHash);
                startActivity(qrIntent);

                clearFields();
            } else {
                Toast.makeText(this, "Failed to save collection", Toast.LENGTH_LONG).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String getTextSafe(EditText et) {
        return et != null && et.getText() != null ? et.getText().toString().trim() : "";
    }

    private String getTextSafe(TextView tv) {
        return tv != null && tv.getText() != null ? tv.getText().toString().trim() : "";
    }

    private void clearFields() {
        inputCollectionDatetime.setText("");
        inputHerbSpecies.setText("");
        inputVariety.setText("");
        inputBatchId.setText("");
        inputQuantity.setText("");
        inputMoisture.setText("");
        inputSoilId.setText("");
        inputQualityNotes.setText("");
        textGeoCoordinates.setText("");
        selectedPhotoUriString = "";
        selectedCertificateUriString = "";
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri selectedFile = data.getData();
            if (requestCode == REQUEST_PHOTO && selectedFile != null) {
                selectedPhotoUriString = selectedFile.toString();
                Toast.makeText(this, "Photo selected", Toast.LENGTH_SHORT).show();
            } else if (requestCode == REQUEST_CERTIFICATE && selectedFile != null) {
                selectedCertificateUriString = selectedFile.toString();
                Toast.makeText(this, "Certificate selected", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                fetchCurrentLocation();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
