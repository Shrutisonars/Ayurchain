package com.example.ayurchain;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    // Views
    private EditText tvUserId, etPassword;
    private Button btnLogin;
    private TextView tvRegisterHere;

    // DB helper
    private DatabaseHelper databaseHelper;

    // Map roles to home activities
    private final Map<String, Class<?>> roleMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        tvUserId = findViewById(R.id.tv_userid);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_register); // Make sure your login button in XML is btn_login
        tvRegisterHere = findViewById(R.id.tv_register_here);

        // Initialize DB helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize role map
        roleMap.put("farmer", FarmerHomeActivity.class);
        roleMap.put("local collector", CollectorHomeActivity.class);
        roleMap.put("packaging unit", PackagingUnitHomeActivity.class);
        roleMap.put("wholeseller", WholesellerHomeActivity.class);
        roleMap.put("retailer", RetailerHomeActivity.class);

        // Login click
        btnLogin.setOnClickListener(v -> loginUser());

        // Navigate to registration page
        tvRegisterHere.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, RegistrationActivity.class))
        );
    }

    private void loginUser() {
        String userId = tvUserId.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (userId.isEmpty()) {
            tvUserId.setError("User ID required");
            tvUserId.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            etPassword.setError("Password required");
            etPassword.requestFocus();
            return;
        }

        Cursor cursor = null;
        try {
            // Query users table for the role
            cursor = databaseHelper.getData(
                    "users",
                    new String[]{"role"},
                    "user_id=? AND password=?",
                    new String[]{userId, password}
            );

            if (cursor != null && cursor.moveToFirst()) {
                String savedRole = cursor.getString(cursor.getColumnIndexOrThrow("role"));
                if (savedRole == null) savedRole = "";
                savedRole = savedRole.toLowerCase().trim();

                Toast.makeText(this, "Login successful as " + savedRole, Toast.LENGTH_SHORT).show();
                Log.d("LOGIN", "User " + userId + " role=" + savedRole);

                openHomePage(savedRole);
            } else {
                Toast.makeText(this, "Invalid User ID or Password", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("DB_ERROR", "loginUser: error querying DB", e);
            Toast.makeText(this, "Login error (see logcat)", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null && !cursor.isClosed()) cursor.close();
        }
    }

    private void openHomePage(String role) {
        Class<?> targetActivity = roleMap.get(role);
        if (targetActivity != null) {
            startActivity(new Intent(this, targetActivity));
            finish();
        } else {
            Toast.makeText(this, "Unknown role!", Toast.LENGTH_SHORT).show();
            Log.e("LOGIN", "Unknown role: " + role);
        }
    }
}
