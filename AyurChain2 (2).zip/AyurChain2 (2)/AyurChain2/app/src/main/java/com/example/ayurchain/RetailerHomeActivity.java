package com.example.ayurchain;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class RetailerHomeActivity extends AppCompatActivity {

    private EditText inputReceiptDateTime, inputBatchIDs, inputQuantityReceived, inputStorageConditions;
    private Button btnScanQR, btnSubmit;

    private Calendar receiptCalendar;

    private ActivityResultLauncher<ScanOptions> qrScannerLauncher;

    // DB helper
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.retailerhome);

        // init DB helper
        databaseHelper = new DatabaseHelper(this);

        // views (ensure these IDs exist in retailerhome.xml)
        inputReceiptDateTime = findViewById(R.id.input_receipt_datetime);
        inputBatchIDs = findViewById(R.id.input_batch_ids);
        inputQuantityReceived = findViewById(R.id.input_quantity_received);
        inputStorageConditions = findViewById(R.id.input_storage_conditions);

        btnScanQR = findViewById(R.id.btn_scan_qr);
        btnSubmit = findViewById(R.id.btn_submit_retailer);

        receiptCalendar = Calendar.getInstance();

        // register QR scanner launcher
        qrScannerLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (result != null && result.getContents() != null) {
                Toast.makeText(RetailerHomeActivity.this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();
                inputBatchIDs.setText(result.getContents());
            }
        });

        // listeners
        if (inputReceiptDateTime != null) {
            inputReceiptDateTime.setOnClickListener(v -> showDateTimePicker());
        }
        if (btnScanQR != null) {
            btnScanQR.setOnClickListener(v -> startQRScanner());
        }
        if (btnSubmit != null) {
            btnSubmit.setOnClickListener(v -> submitRetailerInfo());
        }
    }

    private void startQRScanner() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("Scan a QR code");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        qrScannerLauncher.launch(options);
    }

    private void showDateTimePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    receiptCalendar.set(Calendar.YEAR, year);
                    receiptCalendar.set(Calendar.MONTH, month);
                    receiptCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                    TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                            (timeView, hourOfDay, minute) -> {
                                receiptCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                                receiptCalendar.set(Calendar.MINUTE, minute);
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                                inputReceiptDateTime.setText(sdf.format(receiptCalendar.getTime()));
                            },
                            receiptCalendar.get(Calendar.HOUR_OF_DAY),
                            receiptCalendar.get(Calendar.MINUTE),
                            true);
                    timePickerDialog.show();

                },
                receiptCalendar.get(Calendar.YEAR),
                receiptCalendar.get(Calendar.MONTH),
                receiptCalendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void submitRetailerInfo() {
        String receiptDateTime = getTextSafe(inputReceiptDateTime);
        String batchIDs = getTextSafe(inputBatchIDs);
        String quantity = getTextSafe(inputQuantityReceived);
        String storage = getTextSafe(inputStorageConditions);

        // validate required fields
        if (receiptDateTime.isEmpty() || batchIDs.isEmpty() || quantity.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean saved = false;
        try {
            // calls DatabaseHelper.insertRetailerData(receiptDatetime, batchIds, quantityReceived, storageConditions)
            saved = databaseHelper.insertRetailerData(receiptDateTime, batchIDs, quantity, storage);
        } catch (Exception e) {
            Log.e("DB_ERROR", "Error inserting retailer data", e);
            saved = false;
        }

        if (saved) {
            Toast.makeText(this, "Retailer info saved successfully", Toast.LENGTH_LONG).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to save retailer info", Toast.LENGTH_LONG).show();
        }
    }

    private String getTextSafe(EditText et) {
        return (et == null || et.getText() == null) ? "" : et.getText().toString().trim();
    }

    private void clearFields() {
        if (inputReceiptDateTime != null) inputReceiptDateTime.setText("");
        if (inputBatchIDs != null) inputBatchIDs.setText("");
        if (inputQuantityReceived != null) inputQuantityReceived.setText("");
        if (inputStorageConditions != null) inputStorageConditions.setText("");
    }
}
