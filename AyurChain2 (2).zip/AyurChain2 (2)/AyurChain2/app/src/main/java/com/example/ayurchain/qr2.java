package com.example.ayurchain;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class qr2 extends AppCompatActivity {

    private TextView textQrInfo;
    private ImageView qrImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qr2); // Layout for retailer QR

        textQrInfo = findViewById(R.id.text_qr_info);
        qrImage = findViewById(R.id.qr_image);

        // Get retailer data from intent
        String retailerId = getIntent().getStringExtra("RETAILER_ID");
        String retailerName = getIntent().getStringExtra("RETAILER_NAME");
        String storeLocation = getIntent().getStringExtra("STORE_LOCATION");
        String receivedBatchIds = getIntent().getStringExtra("RECEIVED_BATCH_IDS");
        String contact = getIntent().getStringExtra("CONTACT");
        String email = getIntent().getStringExtra("EMAIL");

        // Prepare QR content dynamically
        String qrContent = "Retailer ID: " + (retailerId != null ? retailerId : "N/A") + "\n" +
                "Name: " + (retailerName != null ? retailerName : "N/A") + "\n" +
                "Store Location: " + (storeLocation != null ? storeLocation : "N/A") + "\n" +
                "Received Batch IDs: " + (receivedBatchIds != null ? receivedBatchIds : "N/A") + "\n" +
                "Contact: " + (contact != null ? contact : "N/A") + "\n" +
                "Email: " + (email != null ? email : "N/A");

        textQrInfo.setText(qrContent);

        // Generate QR code
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.encodeBitmap(qrContent, BarcodeFormat.QR_CODE, 400, 400);
            qrImage.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }
}
