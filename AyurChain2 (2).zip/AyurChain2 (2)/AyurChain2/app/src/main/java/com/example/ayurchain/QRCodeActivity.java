package com.example.ayurchain;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class QRCodeActivity extends AppCompatActivity {

    private TextView textQrInfo;
    private ImageView qrImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_code);

        textQrInfo = findViewById(R.id.text_qr_info);
        qrImage = findViewById(R.id.qr_image);

        // Get all data from the intent
        String collectionDateTime = getIntent().getStringExtra("COLLECTION_DATETIME");
        String geoCoordinates = getIntent().getStringExtra("GEO_COORDINATES");
        String harvestMethod = getIntent().getStringExtra("HARVEST_METHOD");
        String herbSpecies = getIntent().getStringExtra("HERB_SPECIES");
        String variety = getIntent().getStringExtra("VARIETY");
        String batchId = getIntent().getStringExtra("BATCH_ID");
        String quantity = getIntent().getStringExtra("QUANTITY");
        String moisture = getIntent().getStringExtra("MOISTURE");
        String soilId = getIntent().getStringExtra("SOIL_ID");
        String qualityNotes = getIntent().getStringExtra("QUALITY_NOTES");
        String photosHash = getIntent().getStringExtra("PHOTOS_HASH");
        String certificatesHash = getIntent().getStringExtra("CERTIFICATES_HASH");

        // Prepare QR content with all available data
        String qrContent = "Collection Date: " + (collectionDateTime != null ? collectionDateTime : "N/A") + "\n" +
                "Geo-coordinates: " + (geoCoordinates != null ? geoCoordinates : "N/A") + "\n" +
                "Harvest Method: " + (harvestMethod != null ? harvestMethod : "N/A") + "\n" +
                "Herb Species: " + (herbSpecies != null ? herbSpecies : "N/A") + "\n" +
                "Variety: " + (variety != null ? variety : "N/A") + "\n" +
                "Batch ID: " + (batchId != null ? batchId : "N/A") + "\n" +
                "Quantity: " + (quantity != null ? quantity : "N/A") + "\n" +
                "Moisture: " + (moisture != null ? moisture : "N/A") + "\n" +
                "Soil ID: " + (soilId != null ? soilId : "N/A") + "\n" +
                "Quality Notes: " + (qualityNotes != null ? qualityNotes : "N/A") + "\n" +
                "Photos Hash: " + (photosHash != null ? photosHash : "N/A") + "\n" +
                "Certificates Hash: " + (certificatesHash != null ? certificatesHash : "N/A");

        textQrInfo.setText(qrContent);

        // Generate QR code
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.encodeBitmap(qrContent, BarcodeFormat.QR_CODE, 400, 400);
            qrImage.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }
}