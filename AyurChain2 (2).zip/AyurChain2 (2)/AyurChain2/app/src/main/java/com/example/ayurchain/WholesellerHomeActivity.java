package com.example.ayurchain;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class WholesellerHomeActivity extends AppCompatActivity {

    private EditText inputWarehouseLocation, inputReceivingDatetime, inputBatchIDs,
            inputQuantityReceived, inputStorageConditions, inputDispatchDatetime,
            inputTransportMode, inputInvoiceNumber;

    private Button btnScanQR, btnPickReceivingDatetime, btnPickDispatchDatetime, btnSubmit;

    private Calendar receivingCalendar, dispatchCalendar;

    private ActivityResultLauncher<ScanOptions> qrScannerLauncher;

    // Database helper
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wholesellerhome); // XML layout file

        // Initialize DB helper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views (ensure these IDs exist in your layout)
        inputWarehouseLocation = findViewById(R.id.input_warehouse_location);
        inputReceivingDatetime = findViewById(R.id.input_receiving_datetime);
        inputBatchIDs = findViewById(R.id.input_batch_ids);
        inputQuantityReceived = findViewById(R.id.input_quantity_received);
        inputStorageConditions = findViewById(R.id.input_storage_conditions);
        inputDispatchDatetime = findViewById(R.id.input_dispatch_datetime);
        inputTransportMode = findViewById(R.id.input_transport_mode);
        inputInvoiceNumber = findViewById(R.id.input_invoice_number);

        btnScanQR = findViewById(R.id.btn_scan_qr);
          // optional
        btnSubmit = findViewById(R.id.btn_submit_wholesaler);

        receivingCalendar = Calendar.getInstance();
        dispatchCalendar = Calendar.getInstance();

        // Initialize QR Scanner launcher
        qrScannerLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (result != null && result.getContents() != null) {
                Toast.makeText(this, "QR Code: " + result.getContents(), Toast.LENGTH_LONG).show();
                // set scanned value to batch IDs field
                inputBatchIDs.setText(result.getContents());
            }
        });

        // QR Scan
        if (btnScanQR != null) {
            btnScanQR.setOnClickListener(v -> scanQRCode());
        }

        // Date & Time Pickers - clicking either the EditText or the pick button opens picker
        if (inputReceivingDatetime != null) {
            inputReceivingDatetime.setOnClickListener(v -> pickDateTime(receivingCalendar, inputReceivingDatetime));
        }
        if (btnPickReceivingDatetime != null) {
            btnPickReceivingDatetime.setOnClickListener(v -> pickDateTime(receivingCalendar, inputReceivingDatetime));
        }

        if (inputDispatchDatetime != null) {
            inputDispatchDatetime.setOnClickListener(v -> pickDateTime(dispatchCalendar, inputDispatchDatetime));
        }
        if (btnPickDispatchDatetime != null) {
            btnPickDispatchDatetime.setOnClickListener(v -> pickDateTime(dispatchCalendar, inputDispatchDatetime));
        }

        // Submit Button
        if (btnSubmit != null) {
            btnSubmit.setOnClickListener(v -> submitWholesalerInfo());
        }
    }

    // Launch actual QR code scanner
    private void scanQRCode() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("Scan a QR code");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        qrScannerLauncher.launch(options);
    }

    // Generic Date & Time Picker
    private void pickDateTime(Calendar calendar, EditText editText) {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, month);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                    TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                            (timeView, hourOfDay, minute) -> {
                                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                                calendar.set(Calendar.MINUTE, minute);
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                                editText.setText(sdf.format(calendar.getTime()));
                            },
                            calendar.get(Calendar.HOUR_OF_DAY),
                            calendar.get(Calendar.MINUTE),
                            true);
                    timePickerDialog.show();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    // Submit info and save to SQLite DB
    private void submitWholesalerInfo() {
        String warehouseLocation = getTextSafe(inputWarehouseLocation);
        String receivingDatetime = getTextSafe(inputReceivingDatetime);
        String batchIDs = getTextSafe(inputBatchIDs);
        String quantity = getTextSafe(inputQuantityReceived);
        String storage = getTextSafe(inputStorageConditions);
        String dispatchDatetime = getTextSafe(inputDispatchDatetime);
        String transport = getTextSafe(inputTransportMode);
        String invoice = getTextSafe(inputInvoiceNumber);

        // Basic validation
        if (warehouseLocation.isEmpty() || receivingDatetime.isEmpty() || batchIDs.isEmpty() || quantity.isEmpty() || dispatchDatetime.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // documentsHash not collected in UI right now — pass empty string or implement a field if needed
        String documentsHash = "";

        // Insert into DB using your DatabaseHelper
        boolean saved = false;
        try {
            saved = databaseHelper.insertWholesalerData(
                    warehouseLocation,
                    receivingDatetime,
                    batchIDs,
                    quantity,
                    storage,
                    dispatchDatetime,
                    transport,
                    invoice,
                    documentsHash
            );
        } catch (Exception e) {
            Log.e("DB_ERROR", "Error inserting wholesaler data", e);
            saved = false;
        }

        if (saved) {
            Toast.makeText(this, "Wholesaler info saved successfully", Toast.LENGTH_LONG).show();
            clearFields();
        } else {
            Toast.makeText(this, "Failed to save wholesaler info", Toast.LENGTH_LONG).show();
        }
    }

    private String getTextSafe(EditText et) {
        return et == null ? "" : (et.getText() != null ? et.getText().toString().trim() : "");
    }

    private void clearFields() {
        if (inputWarehouseLocation != null) inputWarehouseLocation.setText("");
        if (inputReceivingDatetime != null) inputReceivingDatetime.setText("");
        if (inputBatchIDs != null) inputBatchIDs.setText("");
        if (inputQuantityReceived != null) inputQuantityReceived.setText("");
        if (inputStorageConditions != null) inputStorageConditions.setText("");
        if (inputDispatchDatetime != null) inputDispatchDatetime.setText("");
        if (inputTransportMode != null) inputTransportMode.setText("");
        if (inputInvoiceNumber != null) inputInvoiceNumber.setText("");
    }
}
